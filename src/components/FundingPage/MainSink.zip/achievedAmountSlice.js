import { createSlice } from '@reduxjs/toolkit';

const achievedAmountSlice = createSlice({
  name: 'achievedAmount',
  initialState: 0,
  reducers: {
    incrementByAmount: (state, action) => {
      return state + action.payload;
    },
  },
});

export const { incrementByAmount } = achievedAmountSlice.actions;
export default achievedAmountSlice.reducer;