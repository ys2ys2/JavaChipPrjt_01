import React from 'react';

const AchievedAmountDisplay = ({ achievedAmount }) => {
  return (
    <div className="F_funding-status">
      <h3>335% 달성</h3>
      <h2>목표 금액 :</h2>
      <h3>달성 금액 : {achievedAmount.toLocaleString()} 원 달성</h3>
      <p>80명 참여</p>
    </div>
  );
}

export default AchievedAmountDisplay;
