import { useState, useEffect } from 'react';

export function useAchievedAmount(onAchievedAmountChange) {
  const [achievedAmount, setAchievedAmount] = useState(0);

  useEffect(() => {
    if (onAchievedAmountChange) {
      onAchievedAmountChange(achievedAmount);
    }
  }, [achievedAmount, onAchievedAmountChange]);

  const addAchievedAmount = (amount) => {
    setAchievedAmount(prev => prev + amount);
  };

  return { achievedAmount, addAchievedAmount };
}
